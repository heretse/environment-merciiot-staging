
-- add sample data for device
USE `cloudb_dev`;
-- add gateway
INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'1c497be8745a',
'Sample Gateway',
3,
159,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);
-- add 三合一溫濕度
INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000001',
'sensor hub',
3,
18,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);

INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000001_1',
'溫濕度感測器',
3,
18,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);
-- add 人員安全管理
INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000002',
'位置偵測A',
3,
165,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);

INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000003',
'位置偵測B',
3,
165,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);
-- add 站點資訊
INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000004',
'sample站點',
3,
165,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);
INSERT INTO `cloudb_dev`.`api_device_info`
(
`device_mac`,
`device_name`,
`device_status`,
`device_type`,
`device_share`,
`device_active_time`,
`device_bind_time`,
`device_cp_id`,
`device_user_id`,
`createTime`,
`createUser`)
VALUES
(
'0000000001000005',
'sample機台',
3,
165,
0,
current_time(),
current_time(),
1,
1,
current_time(),
1);

-- set up notification_service_db
USE `notification_service_db`;
INSERT INTO `notification_service_db`.`terminal`
(
`user_id`,
`terminal_group_id`,
`mac`,
`remark`,
`in_time`)
VALUES
(
1,
1,
'1c497be8745a',
'Sample Gateway',
current_time());
INSERT INTO `notification_service_db`.`terminal`
(
`user_id`,
`terminal_group_id`,
`mac`,
`remark`,
`in_time`)
VALUES
(1,
1,
'0000000001000001_1',
'溫濕度感測器',
current_time());
INSERT INTO `notification_service_db`.`terminal_group`
(`id`,
`user_id`,
`group_name`,
`remark`,
`in_time`)
VALUES
(1,
1,
'sample group',
'sample group',
current_time());
INSERT INTO `notification_service_db`.`notification_terminal_relation`
(`user_id`,
`notification_group_id`,
`terminal_group_id`,
`in_time`)
VALUES
(1,
1,
1,
current_time());

INSERT INTO `notification_service_db`.`notification_object`
(`id`,
`user_id`,
`object_name`,
`remark`,
`in_time`)
VALUES
(1,
1,
'sample user',
'sample',
current_time());

INSERT INTO `notification_service_db`.`notification_group`
(`id`,
`user_id`,
`group_name`,
`delay`,
`in_time`)
VALUES
(1,
1,
'sample user group',
0,
current_time());
INSERT INTO `notification_service_db`.`object_method_relation`
(`id`,
`user_id`,
`notification_object_id`,
`notification_method_id`,
`notification_method`,
`notification_account`,
`notification_enabled`,
`remark`,
`in_time`)
VALUES
(1,
1,
1,
1,
'eMail',
'demo@gemteks.com',
1,
'',
current_time());






pwd=`pwd`
echo $pwd 
read -s -p "Enter MySQL root Password: " pswd
echo 'already receive MySQL password'
# import mongodb sample data
docker cp $pwd/mongo-sample mongodb:/backup
docker cp $pwd/mongorestore.sh mongodb:/docker-entrypoint-initdb.d/mongorestore.sh
docker exec mongodb /bin/sh -c '/docker-entrypoint-initdb.d/mongorestore.sh'
# import MySQL sample data
docker exec -i mysqldb mysql -u root --password=$pswd --default-character-set=utf8 < $pwd/sample.sql
# import cloudant data
read -s -p "Enter Cloudant admin Password: " cpwd
echo 'already receive cloudant password'
read -s -p "Enter Cloudant IP: " cloudant
echo 'already receive IP:'${cloudant}

C="http://admin:"${cpwd}"@"${cloudant}":8081/web_info"
D="http://admin:"${cpwd}"@"${cloudant}":8081/plan_info/sample/sampelData"
echo 'import dashboard setting'
curl $C -X POST -H "Content-Type: application/json" -d @"web_info.json"
echo 'import plan info'
curl $D -X PUT -H "Content-Type: image/png" --data-binary @"factory.png"
